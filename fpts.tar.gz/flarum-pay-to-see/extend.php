<?php

use Flarum\Extend;
use Flarum\Api\Serializer\BasicPostSerializer;
use Flarum\Api\Serializer\DiscussionSerializer;
use Flarum\Api\Serializer\ForumSerializer;
use Flarum\Discussion\Event\Saving as DiscussionSaving;
use Flarum\Post\Event\Saving as PostSaving;

use Ziven\pay2see\ProcessContent;
use Ziven\pay2see\AddDiscussionPaidAttributes;
use Ziven\pay2see\Controller\PayToSeePurchaseController;
use Ziven\pay2see\Controller\ListPayToSeePurchasedUserController;
use Ziven\pay2see\Controller\PayToSeeSetController;
use Ziven\pay2see\Listeners\AddPayToSeeDiscussion;
use Ziven\pay2see\Listeners\AddPayToSeePost;
use Ziven\pay2see\Notification\PayToSeeBlueprint;

$extend = [
    (new Extend\Frontend('admin'))->js(__DIR__.'/js/dist/admin.js')->css(__DIR__.'/less/admin.less'),
    (new Extend\Frontend('forum'))->js(__DIR__ . '/js/dist/forum.js')->css(__DIR__.'/less/forum.less'),
    (new Extend\Locales(__DIR__ . '/locale')),
    (new Extend\Routes('api'))
        ->post('/pay2seePurchase', 'pay2see.create', PayToSeePurchaseController::class)
        ->get('/pay2seePurchase', 'pay2see.purchased', ListPayToSeePurchasedUserController::class)
        ->post('/pay2seeSet', 'pay2see.set', PayToSeeSetController::class),
    (new Extend\Event())
        ->listen(DiscussionSaving::class, AddPayToSeeDiscussion::class)
        ->listen(PostSaving::class, AddPayToSeePost::class),
    (new Extend\ApiSerializer(DiscussionSerializer::class))
        ->attributes(AddDiscussionPaidAttributes::class)
        ->attribute('pay2seeCount', function (DiscussionSerializer $serializer, $discussion) {
            return $discussion->pay2see_count;
        }),
    (new Extend\ApiSerializer(BasicPostSerializer::class))
        ->attributes(ProcessContent::class),
    (new Extend\ApiSerializer(ForumSerializer::class))
        ->attribute('allowUsePay2See', function (ForumSerializer $serializer) {
            return $serializer->getActor()->hasPermission("pay2see.allowUsePay2See");
        })
        ->attribute('allowSetPay2See', function (ForumSerializer $serializer) {
            return $serializer->getActor()->hasPermission("pay2see.allowSetPay2See");
        })
        ->attribute('allowPurchasePay2See', function (ForumSerializer $serializer) {
            return $serializer->getActor()->hasPermission("pay2see.allowPurchasePay2See");
        }),
    (new Extend\Settings())
        ->default('pay2see.pay2seeAllowTags', [])
        ->serializeToForum('pay2seeAllowTags', 'pay2see.pay2seeAllowTags')
        ->serializeToForum('pay2seeContentBadge', 'pay2see.pay2seeContentBadge', 'strval'),
    (new Extend\Notification())
        ->type(PayToSeeBlueprint::class, DiscussionSerializer::class, ['alert']),

];

return $extend;