const config = require("flarum-webpack-config");

module.exports = config({
  useExtensions: ["ziiven-decoration-store"],
});