<?php

namespace Ziven\pay2see\Notification;

use Flarum\Discussion\Discussion;
use Ziven\pay2see\Model\PaidDiscussion;
use Flarum\Notification\Blueprint\BlueprintInterface;

class PayToSeeBlueprint implements BlueprintInterface{
    public $pay2seePurchase;

    public function __construct(PaidDiscussion $purchase){
        $this->pay2seePurchase = $purchase;
    }

    public function getSubject(){
        return $this->pay2seePurchase->purchasedDiscussion;
    }

    public function getFromUser(){
        return $this->pay2seePurchase->purchasedByUser;
    }

    public function getData(){
        return null;
    }
    
    public static function getType(){
        return 'pay2see';
    }

    public static function getSubjectModel(){
        return Discussion::class;
    }
}
