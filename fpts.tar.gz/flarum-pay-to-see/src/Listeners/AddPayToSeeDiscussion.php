<?php


namespace Ziven\pay2see\Listeners;

use Flarum\Discussion\Event\Saving;
use Flarum\Foundation\ValidationException;
use Flarum\Locale\Translator;
use Flarum\Settings\SettingsRepositoryInterface;
use Illuminate\Support\Arr;

class AddPayToSeeDiscussion{
    protected $translator;
    protected $settings;

    public function __construct(Translator $translator, SettingsRepositoryInterface $settings){
        $this->translator = $translator;
        $this->settings = $settings;
    }

    public function handle(Saving $event){
        if(Arr::get($event->data, 'relationships.recipientUsers') || Arr::get($event->data, 'relationships.recipientGroups')){
            return;
        }

        $pay2seeAllowTags = $this->settings->get('pay2see.pay2seeAllowTags', []);
        $errorMessage = "";

        if(gettype($pay2seeAllowTags)==="string"){
            $pay2seeAllowTags = json_decode($pay2seeAllowTags);
        }

        if(count($pay2seeAllowTags)===0){
            $allowUsePay2SeeInTag = true;
        }else{
            $allowUsePay2SeeInTag = false;
            
            if(isset($event->data["relationships"])){
                $tags = $event->data["relationships"]["tags"]["data"];

                foreach($tags as $key=>$value){
                    $tagID = intval($value["id"]);

                    if(in_array($tagID, $pay2seeAllowTags)){
                        $allowUsePay2SeeInTag = true;
                        break;
                    }
                }
            }
        }

        $actor = $event->actor;
        $user = $event->user;
        $allowUsePay2See = $actor->can('pay2see.allowUsePay2See', $user);
        $pay2seeAmount = Arr::get($event->data, 'attributes.pay2seeAmount');

        if(isset($pay2seeAmount)){
            if($allowUsePay2See && $allowUsePay2SeeInTag){
                $isAnonymous = Arr::get($event->data, 'attributes.isAnonymous');

                if($isAnonymous===true){
                    $errorMessage = "pay-to-see.forum.not_support_anonymous";
                }else{
                    $event->discussion->pay2see_cost = round($pay2seeAmount, 2);
                }
            }else{
                $errorMessage = "pay-to-see.forum.set_error_no_permission";
            }
        }

        if($errorMessage!==""){
            throw new ValidationException(['message' => $this->translator->trans($errorMessage)]); 
        }
    }
}
