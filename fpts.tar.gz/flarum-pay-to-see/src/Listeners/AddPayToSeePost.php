<?php


namespace Ziven\pay2see\Listeners;

use Flarum\Post\Event\Saving;
use Flarum\Foundation\ValidationException;
use Flarum\Locale\Translator;
use Flarum\Settings\SettingsRepositoryInterface;
use Illuminate\Support\Arr;

class AddPayToSeePost{
    protected $translator;
    protected $settings;

    public function __construct(Translator $translator, SettingsRepositoryInterface $settings){
        $this->translator = $translator;
        $this->settings = $settings;
    }

    public function handle(Saving $event){
        $errorMessage = "";

        $actor = $event->actor;
        $post = $event->post;
        $discussion = $post->discussion;
        $pay2see_cost = $discussion->pay2see_cost;
        $currentUserID = $actor->id;
        $discussionUserID = $discussion->user_id;

        if(isset($pay2see_cost) && $currentUserID==$discussionUserID){
            $isAnonymous = Arr::get($event->data, 'attributes.isAnonymous');

            if($isAnonymous===true){
                $errorMessage = "pay-to-see.forum.not_support_anonymous";
            }
        }

        if($errorMessage!==""){
            throw new ValidationException(['message' => $this->translator->trans($errorMessage)]); 
        }
    }
}
