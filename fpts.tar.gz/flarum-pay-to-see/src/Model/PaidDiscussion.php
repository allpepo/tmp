<?php

namespace Ziven\pay2see\Model;

use Flarum\Database\AbstractModel;
use Flarum\Database\ScopeVisibilityTrait;
use Flarum\User\User;
use Flarum\Discussion\Discussion;

class PaidDiscussion extends AbstractModel{
    use ScopeVisibilityTrait;
    protected $table = 'ziven_paid_discussion';
    
    public function purchasedByUser(){
        return $this->hasOne(User::class, 'id', 'user_id');
    }
    
    public function purchasedDiscussion(){
        return $this->hasOne(Discussion::class, 'id', 'discussion_id');
    }
}
