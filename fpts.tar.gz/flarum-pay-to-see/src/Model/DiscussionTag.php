<?php

namespace Ziven\pay2see\Model;

use Flarum\Database\AbstractModel;
use Flarum\Database\ScopeVisibilityTrait;

class DiscussionTag extends AbstractModel{
    use ScopeVisibilityTrait;
    protected $table = 'discussion_tag';
}
