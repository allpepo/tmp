<?php

namespace Ziven\pay2see;

use Flarum\Locale\Translator;
use Ziven\pay2see\Model\PaidDiscussion;

class ProcessContent{
    protected $translator;

    public function __construct(Translator $translator){
        $this->translator = $translator;
    }

    public function __invoke($serializer, $model, $attributes){
        if (isset($attributes["contentHtml"])) {
            $newContent = $attributes['contentHtml'];
            $discussionID = $model->discussion_id;
            $actor = $serializer->getActor();
            $currentUserID = $actor->id;
            $discussionOwnerID = $model->discussion->user_id;
            $discussionCost = $model->discussion->pay2see_cost;
            $postOwnerID = $model->user_id;

            if($postOwnerID!==$discussionOwnerID || !isset($discussionCost)){

            }else{
                $isPaid = false;
                $paidContentText = $this->translator->trans('pay-to-see.forum.pay_to_see_content');
                $allowBypassPay2See = $actor->can('pay2see.allowBypassPay2See', $model->user);

                if($model->number==1){
                    $count = PaidDiscussion::where(['user_id'=>$currentUserID,'discussion_id'=>$discussionID])->count();
                    $serializer->is_paid = $isPaid = $count>0;
                }else{
                    $isPaid = property_exists($serializer, 'is_paid')?$serializer->is_paid:false;
                }
                
                if($isPaid===true || $currentUserID===$discussionOwnerID || $allowBypassPay2See){
                    $paidContentClassName = "pay2see_gray";
                    $paidHeaderClassName = "pay2see_header_gray";
                    $paidContentText = $this->translator->trans('pay-to-see.forum.pay_to_see_owner_bypass');

                    if($currentUserID!==$discussionOwnerID && $isPaid===true){
                        $paidContentText = $this->translator->trans('pay-to-see.forum.purchased_content');
                        $paidContentClassName = "pay2see_green";
                        $paidHeaderClassName = "pay2see_header_green";
                    }

                    if($isPaid===false && $allowBypassPay2See){
                        $paidContentText = $this->translator->trans('pay-to-see.forum.pay_to_see_content_bypass');
                    }

                    $attributes['contentHtml'] = $newContent = str_replace('[pay]','<div class="'.$paidContentClassName.'"><div class="'.$paidHeaderClassName.'">'.$paidContentText.'</div>',$newContent);
                    $attributes['contentHtml'] = $newContent = str_replace('[/pay]','</div>',$newContent);
                }else{
                    $replacement = '<blockquote style="text-align:center;padding:30px"><div><p>'.$this->translator->trans('pay-to-see.forum.pay_to_see_content').'</p></div></blockquote>';
                    $attributes['contentHtml'] = self::replaceContent($newContent,"[pay]","[/pay]",$replacement);
                }
            }
        }

        return $attributes;
    }

    public function replaceContent($str, $start, $end, $replacement) {
        $start = preg_quote($start, '/');
        $end = preg_quote($end, '/');
        $regex = "/$start(.*?)$end/is";

        return preg_replace($regex,$replacement,$str);
    }

    public function getContent($string, $start, $end){
        $start = preg_quote($start, '/');
        $end = preg_quote($end, '/');
        $regex = "/$start(.*?)$end/is";
        preg_match($regex, $string, $matches);
        
        return $matches[1];
    }
}
