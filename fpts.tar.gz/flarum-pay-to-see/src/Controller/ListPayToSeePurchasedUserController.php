<?php

namespace Ziven\pay2see\Controller;

use Ziven\pay2see\Serializer\PayToSeeSerializer;
use Ziven\pay2see\Model\PaidDiscussion;

use Flarum\Query\QueryCriteria;
use Flarum\Api\Controller\AbstractListController;
use Psr\Http\Message\ServerRequestInterface;
use Tobscure\JsonApi\Document;
use Flarum\Http\UrlGenerator;

class ListPayToSeePurchasedUserController extends AbstractListController{
    public $serializer = PayToSeeSerializer::class;
    public $include = ['purchasedByUser'];
    protected $url;

    public function __construct(UrlGenerator $url){
        $this->url = $url;
    }

    protected function data(ServerRequestInterface $request, Document $document){
        $include = $this->extractInclude($request);
        $actor = $request->getAttribute('actor');
        $userID = $actor->id;
        $params = $request->getQueryParams();
        $offset = $this->extractOffset($request);
        $limit = $this->extractLimit($request);
        $discussionID = $params['discussionID'];

        $purchasedDataQuery = PaidDiscussion::where(["discussion_id"=>$discussionID]);
        $purchasedData = $purchasedDataQuery
            ->skip($offset)
            ->take($limit + 1)
            ->orderBy('id', 'desc')
            ->get();

        $hasMoreResults = $limit > 0 && $purchasedData->count() > $limit;

        if($hasMoreResults){
            $purchasedData->pop();
        }

        $document->addPaginationLinks(
            $this->url->to('api')->route('pay2see.purchased'),
            $params,
            $offset,
            $limit,
            $hasMoreResults ? null : 0
        );

        $this->loadRelations($purchasedData, $include);

        return $purchasedData;
    }
}
