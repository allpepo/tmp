<?php

namespace Ziven\pay2see\Controller;

use Ziven\pay2see\Serializer\PayToSeeSerializer;
use Ziven\pay2see\Model\PaidDiscussion;
use Ziven\pay2see\Notification\PayToSeeBlueprint;

use Flarum\Settings\SettingsRepositoryInterface;
use Flarum\Api\Controller\AbstractCreateController;
use Flarum\Discussion\Discussion;
use Flarum\User\User;
use Flarum\Foundation\ValidationException;
use Flarum\Locale\Translator;
use Flarum\Notification\NotificationSyncer;
use Psr\Http\Message\ServerRequestInterface;
use Tobscure\JsonApi\Document;
use Illuminate\Support\Carbon;

class PayToSeePurchaseController extends AbstractCreateController{
    public $serializer = PayToSeeSerializer::class;
    protected $settings;
    protected $notifications;
    protected $translator;

    public function __construct(NotificationSyncer $notifications, Translator $translator,SettingsRepositoryInterface $settings){
        $this->settings = $settings;
        $this->notifications = $notifications;
        $this->translator = $translator;
    }

    protected function data(ServerRequestInterface $request, Document $document){
        $requestData = $request->getParsedBody()['data']['attributes'];
        $discussionID = $requestData['discussionID'];
        $currentUserID = $request->getAttribute('actor')->id;

        $discussionData = Discussion::find($discussionID);
        $discussionOwnerID = $discussionData->user_id;
        $errorMessage = "";

        if(!$discussionData){
            $errorMessage = 'pay-to-see.forum.purchase_error_not_found';
        }else{
            $cost = $discussionData->pay2see_cost;

            if(!isset($cost)){
                $errorMessage = 'pay-to-see.forum.purchase_error_not_found';
            }else{
                $currentUserData = User::find($currentUserID);
                $currentUserMoneyRemain = $currentUserData->money-$cost;

                if($currentUserMoneyRemain<0){
                    $errorMessage = 'pay-to-see.forum.purchase_error_insufficient_fund';
                }else{
                    $allowPurchasePay2See = $request->getAttribute('actor')->can('pay2see.allowPurchasePay2See', $currentUserData);

                    if($allowPurchasePay2See){
                        $pay2seePurchase = new PaidDiscussion();
                        $pay2seePurchase->user_id = $currentUserID;
                        $pay2seePurchase->owner_id = $discussionOwnerID;
                        $pay2seePurchase->discussion_id = $discussionID;
                        $pay2seePurchase->cost = $cost;
                        $pay2seePurchase->assigned_at = Carbon::now('Asia/Shanghai');
                        $pay2seePurchase->save();

                        $discussionData->pay2see_count+=1;
                        $discussionData->save();

                        $currentUserData->money = $currentUserMoneyRemain;
                        $currentUserData->save();

                        $discussionOwnerData = User::find($discussionOwnerID);
                        $discussionOwnerData->money+=$cost;
                        $discussionOwnerData->save();

                        $this->notifications->sync(
                            new PayToSeeBlueprint($pay2seePurchase),
                            [$discussionOwnerData]
                        );

                        return $pay2seePurchase;
                    }else{
                        $errorMessage = 'pay-to-see.forum.purchase_error_no_permission';
                    }
                }
            }
        }

        if($errorMessage!==""){
            throw new ValidationException(['message' => $this->translator->trans($errorMessage)]); 
        }
    }
}
