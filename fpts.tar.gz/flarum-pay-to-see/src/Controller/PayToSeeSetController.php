<?php

namespace Ziven\pay2see\Controller;

use Ziven\pay2see\Serializer\PayToSeeSetSerializer;
use Ziven\pay2see\Model\DiscussionTag;

use Flarum\Settings\SettingsRepositoryInterface;
use Flarum\Api\Controller\AbstractCreateController;
use Flarum\Discussion\Discussion;
use Flarum\User\User;
use Flarum\Foundation\ValidationException;
use Flarum\Locale\Translator;
use Psr\Http\Message\ServerRequestInterface;
use Tobscure\JsonApi\Document;

class PayToSeeSetController extends AbstractCreateController{
    public $serializer = PayToSeeSetSerializer::class;
    protected $settings;
    protected $translator;

    public function __construct(Translator $translator,SettingsRepositoryInterface $settings){
        $this->settings = $settings;
        $this->translator = $translator;
    }

    protected function data(ServerRequestInterface $request, Document $document){
        $requestData = $request->getParsedBody()['data']['attributes'];
        $discussionID = $requestData['discussionID'];
        $cost = $requestData['cost'];
        $actor = $request->getAttribute('actor');
        $currentUserID = $actor->id;

        $discussionData = Discussion::find($discussionID);
        $discussionOwnerID = $discussionData->user_id;
        $errorMessage = "";

        if(!$discussionData){
            $errorMessage = 'pay-to-see.forum.purchase_error_not_found';
        }else{
            if(!isset($cost)){
                $errorMessage = 'pay-to-see.forum.purchase_error_not_found';
            }else{
                $currentUserData = User::find($currentUserID);
                $allowUsePay2See = $actor->can('pay2see.allowUsePay2See', $currentUserData);
                $allowSetPay2See = $actor->can('pay2see.allowSetPay2See', $currentUserData);
                $pay2seeAllowTags = $this->settings->get('pay2see.pay2seeAllowTags', []);
                $allowUsePay2SeeInTag = false;

                if(gettype($pay2seeAllowTags)==="string"){
                    $pay2seeAllowTags = json_decode($pay2seeAllowTags);
                }

                if(count($pay2seeAllowTags)===0){
                    $allowUsePay2SeeInTag = true;
                }else{
                    $tags = DiscussionTag::where("discussion_id",$discussionID)->get();

                    foreach($tags as $key=>$value){
                        $tagID = intval($value["tag_id"]);

                        if(in_array($tagID, $pay2seeAllowTags)){
                            $allowUsePay2SeeInTag = true;
                            break;
                        }
                    }
                }

                if((($discussionOwnerID==$currentUserID && $allowUsePay2See) || $allowSetPay2See) && $allowUsePay2SeeInTag){
                    $isAnonymous = $discussionData->anonymous_user_id!==null;

                    if($isAnonymous===true){
                        $errorMessage = "pay-to-see.forum.not_support_anonymous";
                    }else{
                        $discussionData->pay2see_cost = $cost===-1?null:round($cost, 2);
                        $discussionData->save();

                        return $discussionData;

                    }
                }else{
                    $errorMessage = 'pay-to-see.forum.set_error_no_permission';
                }
            }
        }

        if($errorMessage!==""){
            throw new ValidationException(['message' => $this->translator->trans($errorMessage)]); 
        }
    }
}

