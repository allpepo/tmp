<?php

namespace Ziven\pay2see;

use Flarum\Settings\SettingsRepositoryInterface;
use Illuminate\Contracts\Events\Dispatcher;
use Ziven\pay2see\Model\PaidDiscussion;

class AddDiscussionPaidAttributes{
    protected $settings;
    protected $events;

    public function __construct(SettingsRepositoryInterface $settings, Dispatcher $events){
        $this->settings = $settings;
        $this->events = $events;
    }
    
    public function __invoke($serializer, $model, $attributes){
        $actor = $serializer->getActor();
        $currentUserID = $actor->id;
        $discussionID = $model->id;

        $payCount = PaidDiscussion::where(['user_id'=>$currentUserID,'discussion_id'=>$discussionID])->count();
        $attributes['isPaid'] = $payCount>0;
        $attributes['pay2seeCost'] = $model->pay2see_cost;

        return $attributes;
    }
}
