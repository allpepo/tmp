<?php

namespace Ziven\pay2see\Serializer;

use Flarum\Api\Serializer\AbstractSerializer;

class PayToSeeSetSerializer extends AbstractSerializer{
    protected $type = 'pay2seeSet';

    protected function getDefaultAttributes($data){
        $attributes = [
            'id' => $data->id,
            'pay2see_cost' => $data->pay2see_cost,
        ];

        return $attributes;
    }
}
