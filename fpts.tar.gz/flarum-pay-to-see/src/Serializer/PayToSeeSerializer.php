<?php

namespace Ziven\pay2see\Serializer;

use Flarum\Api\Serializer\AbstractSerializer;
use Flarum\Api\Serializer\BasicUserSerializer;

class PayToSeeSerializer extends AbstractSerializer{
    protected $type = 'pay2seePurchase';

    protected function getDefaultAttributes($data){
        $attributes = [
            'id' => $data->id,
            'discussion_id' => $data->discussion_id,
            'user_id' => $data->user_id,
            'owner_id' => $data->owner_id,
            'cost' => $data->cost,
            'assigned_at' => date("Y-m-d H:i:s", strtotime($data->assigned_at))
        ];

        return $attributes;
    }

    protected function purchasedByUser($data){
        return $this->hasOne($data, BasicUserSerializer::class);
    }
}
