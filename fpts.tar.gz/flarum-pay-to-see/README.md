# Pay To See 付费可见内容

A [Flarum](http://flarum.org) premium extension. Allow user to add pay to see content in the post. 
一个Flarum付费扩展。允许用户在帖子中添加付费内容，其他用户需要付费才能看到。

This extension could be very useful for forum that focus on contents. With this extension, a user can set part of his contents as free sample, and allow other users to purchase the rest of the contents if they want to read more.

### Required Extension
- [Money](https://discuss.flarum.org/d/4699-money-extension) by Antoine

### Hightlight Features
- Customizable pay to see content and price
- Permission settings that allow you to choose which user group can use pay to see
- Receive notification when someone purchase your content

### Video Demo
https://youtu.be/uoZMXLCNnGg

### Installation
You need subscribe [this extension](https://extiverse.com/extension/ziiven/flarum-pay-to-see) at Extiverse. Once subscribed, follow the [instructions](https://extiverse.com/premium/subscriptions) at Extiverse to configure composer, and then run the following command to install this extension.

该扩展为付费扩展，请到[这里](https://extiverse.com/extension/ziiven/flarum-pay-to-see)来订阅。订阅后，请参照[这篇文章](https://extiverse.com/premium/subscriptions)来设置你的composer，之后执行下面的命令来安装。

Install with composer:
```sh
composer require ziiven/flarum-pay-to-see
```

### Updating
```sh
composer update ziiven/flarum-pay-to-see
php flarum migrate
php flarum cache:clear
```

### Links
- [Extiverse](https://extiverse.com/extension/ziiven/flarum-pay-to-see)
- [Discussion](https://discuss.flarum.org/d/32052-pay-to-see)
- [Support](https://ziven.flarum.cloud/d/6-pay-to-see-fu-fei-ke-jian-nei-rong)

### ScreenShot
###### Before purchase
![1669384030280](https://user-images.githubusercontent.com/29644610/204000313-5b4e985b-c00e-4214-a7b3-1ce0ece6240b.jpg)
###### After purchase
![1669384065456](https://user-images.githubusercontent.com/29644610/204000318-a9404020-f125-4882-9545-d2c792e96808.jpg)
###### Admin settings
![1669387275448](https://user-images.githubusercontent.com/29644610/204008586-7faec8de-8597-41a6-a1db-dbbd3355a47f.jpg)