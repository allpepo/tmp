<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Schema\Builder;

return [
    'up' => function (Builder $schema) {
        $schema->table('ziven_paid_discussion', function (Blueprint $table) {
            $table->float('cost')->change();
        });
    },
    'down' => function (Builder $schema) {
        $schema->table('ziven_paid_discussion', function (Blueprint $table) {
            $table->integer('cost')->change();
        });
    }
];
