<?php

use Flarum\Database\Migration;

return Migration::addSettings([
    'pay2see.pay2seeContentBadge' => "fas fa-dollar-sign"
]);
